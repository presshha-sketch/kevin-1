import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Lock, Users, Mail, Phone, Building2, MapPin, Globe, ExternalLink } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Lead } from "@shared/schema";

export default function Admin() {
  const [password, setPassword] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [checkingSession, setCheckingSession] = useState(true);

  useEffect(() => {
    fetch("/api/admin/session", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => {
        if (data.isAdmin) setIsAuthenticated(true);
      })
      .finally(() => setCheckingSession(false));
  }, []);

  const loginMutation = useMutation({
    mutationFn: async (pwd: string) => {
      const res = await apiRequest("POST", "/api/admin/login", { password: pwd });
      return res.json();
    },
    onSuccess: () => {
      setIsAuthenticated(true);
      setLoginError("");
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
    },
    onError: () => {
      setLoginError("Incorrect password. Please try again.");
    },
  });

  const { data: leads, isLoading } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
    enabled: isAuthenticated,
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    loginMutation.mutate(password);
  };

  if (checkingSession) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
        <Card className="w-full max-w-sm">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3">
              <Lock className="w-6 h-6 text-primary" />
            </div>
            <CardTitle className="text-xl">Admin Access</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">Enter your password to view leads</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="flex flex-col gap-3">
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                data-testid="input-admin-password"
              />
              {loginError && (
                <p className="text-sm text-destructive">{loginError}</p>
              )}
              <Button type="submit" disabled={!password || loginMutation.isPending} data-testid="button-admin-login">
                {loginMutation.isPending ? "Checking..." : "View Leads"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading || !leads) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30">
        <p className="text-muted-foreground">Loading leads...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between gap-4 flex-wrap mb-8">
          <div>
            <h1 className="text-2xl font-bold" data-testid="text-admin-title">Lead Dashboard</h1>
            <p className="text-muted-foreground text-sm mt-1">{leads.length} total lead{leads.length !== 1 ? "s" : ""}</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="secondary" className="gap-1.5">
              <Users className="w-3.5 h-3.5" />
              {leads.length} leads
            </Badge>
          </div>
        </div>

        {leads.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-16">
              <Users className="w-12 h-12 text-muted-foreground/40 mb-4" />
              <p className="text-lg font-medium text-muted-foreground">No leads yet</p>
              <p className="text-sm text-muted-foreground/70 mt-1">Leads will appear here when someone fills out your contact form.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {leads.map((lead) => (
              <Card key={lead.id} data-testid={`card-lead-${lead.id}`}>
                <CardContent className="pt-6">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-3">
                        <h3 className="font-semibold text-lg" data-testid={`text-lead-name-${lead.id}`}>{lead.name}</h3>
                        <Badge variant="outline">{lead.businessType}</Badge>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Building2 className="w-4 h-4 shrink-0" />
                          <span className="truncate">{lead.businessName}</span>
                        </div>
                        <a href={`mailto:${lead.email}`} className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                          <Mail className="w-4 h-4 shrink-0" />
                          <span className="truncate">{lead.email}</span>
                        </a>
                        <a href={`tel:${lead.phone}`} className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                          <Phone className="w-4 h-4 shrink-0" />
                          <span>{lead.phone}</span>
                        </a>
                        {lead.city && (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <MapPin className="w-4 h-4 shrink-0" />
                            <span className="truncate">{lead.city}</span>
                          </div>
                        )}
                        {lead.website && (
                          <a href={lead.website.startsWith("http") ? lead.website : `https://${lead.website}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                            <Globe className="w-4 h-4 shrink-0" />
                            <span className="truncate">{lead.website}</span>
                          </a>
                        )}
                        {lead.googleListingUrl && (
                          <a href={lead.googleListingUrl.startsWith("http") ? lead.googleListingUrl : `https://${lead.googleListingUrl}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                            <ExternalLink className="w-4 h-4 shrink-0" />
                            <span className="truncate">Google Listing</span>
                          </a>
                        )}
                      </div>

                      {lead.message && (
                        <p className="mt-3 text-sm text-muted-foreground bg-muted/50 rounded-md p-3">{lead.message}</p>
                      )}
                    </div>

                    <div className="text-xs text-muted-foreground/70 whitespace-nowrap sm:text-right">
                      {new Date(lead.createdAt).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                        hour: "numeric",
                        minute: "2-digit",
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
