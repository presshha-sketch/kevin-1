import { HeroSection } from "@/components/hero-section";
import { CredibilityStrip } from "@/components/credibility-strip";
import { ProblemSection } from "@/components/problem-section";
import { HowItWorksSection } from "@/components/how-it-works-section";
import { ServicesSection } from "@/components/services-section";
import { WhyItWorksSection } from "@/components/why-it-works-section";
import { PricingSection } from "@/components/pricing-section";
import { ContactSection } from "@/components/contact-section";
import { FaqSection } from "@/components/faq-section";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <HeroSection />
        <CredibilityStrip />
        <ProblemSection />
        <HowItWorksSection />
        <ServicesSection />
        <WhyItWorksSection />
        <PricingSection />
        <ContactSection />
        <FaqSection />
      </main>
      <Footer />
    </div>
  );
}
