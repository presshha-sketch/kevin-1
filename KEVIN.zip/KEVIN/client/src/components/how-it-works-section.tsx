import { Card } from "@/components/ui/card";
import { Search, Wrench, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

const steps = [
  {
    icon: Search,
    step: "1",
    title: "Audit Your Profile + Competitors",
    description:
      "We analyze your Google Business Profile, identify gaps, and research what your top local competitors are doing to outrank you.",
  },
  {
    icon: Wrench,
    step: "2",
    title: "Fix & Optimize",
    description:
      "We optimize your categories, services, photos, description, attributes, and listings so Google understands exactly what you do and where you do it.",
  },
  {
    icon: TrendingUp,
    step: "3",
    title: "Grow with Ongoing Management",
    description:
      "We keep your profile active with weekly posts, review management, Q&A responses, and performance tracking — so you keep climbing.",
  },
];

export function HowItWorksSection() {
  return (
    <section
      id="how-it-works"
      className="py-20 sm:py-28 bg-muted/30"
      data-testid="section-how-it-works"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <motion.p
            className="text-sm font-semibold tracking-widest uppercase text-primary mb-3"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            How It Works
          </motion.p>
          <motion.h2
            className="text-3xl sm:text-4xl font-bold tracking-tight mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            Three Steps to Local Dominance
          </motion.h2>
          <motion.p
            className="text-muted-foreground text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            A straightforward process designed to get you ranked and generating
            leads as fast as possible.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.12 }}
            >
              <Card
                className="p-7 text-center h-full relative"
                data-testid={`card-step-${index}`}
              >
                <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold mx-auto mb-5">
                  {step.step}
                </div>
                <div className="w-12 h-12 rounded-md bg-primary/8 flex items-center justify-center mx-auto mb-4">
                  <step.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-base font-semibold mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
