import { Card } from "@/components/ui/card";
import { CheckCircle2, Settings, MessageSquare, BarChart3, Globe, Pencil } from "lucide-react";
import { motion } from "framer-motion";

const services = [
  {
    icon: Settings,
    title: "Google Business Profile Optimization",
    description: "Full optimization of your existing profile — categories, services, attributes, photos, and keyword-rich descriptions.",
  },
  {
    icon: Pencil,
    title: "Monthly GBP Management",
    description: "Weekly posts, profile updates, and ongoing monitoring to keep your listing active and competitive.",
  },
  {
    icon: MessageSquare,
    title: "Review Growth & Response Management",
    description: "Systems to earn authentic reviews and professional responses that build trust with Google and customers.",
  },
  {
    icon: Globe,
    title: "Local Listings Consistency",
    description: "Citation cleanup and NAP consistency across directories so Google trusts your business information.",
  },
  {
    icon: BarChart3,
    title: "Simple Monthly Reporting",
    description: "Clear reports on calls, clicks, visibility, and rankings so you always know what's working.",
  },
];

export function ServicesSection() {
  return (
    <section
      id="services"
      className="py-20 sm:py-28"
      data-testid="section-services"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <motion.p
            className="text-sm font-semibold tracking-widest uppercase text-primary mb-3"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            What We Do
          </motion.p>
          <motion.h2
            className="text-3xl sm:text-4xl font-bold tracking-tight mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            We Focus on the Single Biggest Free Lead Source for Local Businesses
          </motion.h2>
          <motion.p
            className="text-muted-foreground text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            When your Google Business Profile is optimized, active, and
            trusted, Google is more likely to show you to nearby customers ready to buy.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5" data-testid="card-services">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.08 }}
            >
              <Card
                className="p-6 h-full"
                data-testid={`service-item-${index}`}
              >
                <div className="w-10 h-10 rounded-md bg-primary/8 flex items-center justify-center mb-4">
                  <service.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="text-base font-semibold mb-2">{service.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{service.description}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
