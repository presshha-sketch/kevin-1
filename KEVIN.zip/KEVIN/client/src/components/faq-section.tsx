import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "How long until I see results?",
    answer:
      "Most clients begin to see noticeable improvements in visibility and engagement within 4-8 weeks. Google rewards consistent activity, so the longer you stay active, the stronger your rankings become. Some competitive markets may take longer, but we set clear expectations from day one.",
  },
  {
    question: "Do you need access to my Google account?",
    answer:
      "Yes, we'll need manager-level access to your Google Business Profile so we can make optimizations, publish posts, and respond to reviews on your behalf. We never change your login credentials and you remain the owner of your profile at all times.",
  },
  {
    question: "What industries do you work best with?",
    answer:
      "We specialize in local service businesses and brick-and-mortar locations — plumbers, HVAC companies, dentists, salons, auto repair shops, attorneys, restaurants, and more. If your customers search for your service + a location (like \"plumber near me\"), we can help.",
  },
  {
    question: "Do you guarantee #1 ranking?",
    answer:
      "No legitimate SEO provider can guarantee a specific ranking — Google's algorithm considers hundreds of factors including location, competition, and search history. What we do guarantee is a fully optimized, consistently active profile that gives you the best possible chance of ranking in the top 3 map results.",
  },
  {
    question: "Can you help if I don't have many reviews?",
    answer:
      "Absolutely. Review growth is a core part of our service. We implement systems to help you consistently earn new, authentic reviews from real customers — and we manage responses to build trust with both Google and future customers.",
  },
  {
    question: "What does it cost?",
    answer:
      "Our full GBP management service is $100 per week, billed weekly. No setup fees, no long-term contracts. You can cancel anytime. We keep it simple so you can focus on running your business.",
  },
  {
    question: "Do you work in multiple cities?",
    answer:
      "Yes. If your business serves multiple cities or locations, we can optimize your profile to improve visibility across your entire service area. For businesses with multiple Google Business Profile listings, we offer multi-location packages — just ask.",
  },
];

export function FaqSection() {
  return (
    <section
      id="faq"
      className="py-20 sm:py-28"
      data-testid="section-faq"
    >
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <motion.p
            className="text-sm font-semibold tracking-widest uppercase text-primary mb-3"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            FAQ
          </motion.p>
          <motion.h2
            className="text-3xl sm:text-4xl font-bold tracking-tight mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            Frequently Asked Questions
          </motion.h2>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
        >
          <Accordion type="single" collapsible className="space-y-2">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="rounded-md border px-5 bg-card"
                data-testid={`faq-item-${index}`}
              >
                <AccordionTrigger className="text-left font-medium text-sm">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}
