import { SiFacebook } from "react-icons/si";
import logoPath from "@assets/C9343283-07B3-4632-BBFA-DD22E79ADCFF_1770732893773.png";

export function Footer() {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  const navLinks = [
    { label: "Services", id: "services" },
    { label: "How It Works", id: "how-it-works" },
    { label: "Why It Works", id: "why-it-works" },
    { label: "Pricing", id: "pricing" },
    { label: "FAQ", id: "faq" },
    { label: "Contact", id: "contact" },
  ];

  return (
    <footer className="border-t py-10" data-testid="footer">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 mb-8">
          <div className="md:col-span-5">
            <button
              onClick={() => scrollTo("hero")}
              className="mb-3 block"
              data-testid="link-footer-logo"
            >
              <img
                src={logoPath}
                alt="GBP Pro Agency"
                className="h-7 w-auto"
              />
            </button>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-sm">
              We optimize and manage Google Business Profiles so local
              businesses get more calls, more visibility, and more customers
              from Google Maps.
            </p>
          </div>

          <div className="md:col-span-3">
            <h4 className="font-semibold mb-3 text-sm">Quick Links</h4>
            <div className="flex flex-col gap-1.5">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollTo(link.id)}
                  className="text-sm text-muted-foreground text-left hover:text-foreground transition-colors"
                  data-testid={`link-footer-${link.id}`}
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          <div className="md:col-span-4">
            <h4 className="font-semibold mb-3 text-sm">Contact</h4>
            <div className="flex flex-col gap-1.5 text-sm text-muted-foreground">
              <a href="mailto:sales@gbpproagency.com" className="hover:text-foreground transition-colors" data-testid="footer-email">sales@gbpproagency.com</a>
              <span data-testid="footer-area">Serving businesses nationwide</span>
              <a
                href="https://www.facebook.com/share/16qifq9aqJ/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 hover:text-foreground transition-colors mt-1"
                data-testid="link-footer-facebook"
              >
                <SiFacebook className="w-4 h-4" />
                GBP Pro Agency
              </a>
            </div>

            <h4 className="font-semibold mb-2 mt-5 text-sm">Legal</h4>
            <div className="flex flex-col gap-1.5">
              <button
                className="text-sm text-muted-foreground text-left hover:text-foreground transition-colors"
                data-testid="link-privacy"
              >
                Privacy Policy
              </button>
              <button
                className="text-sm text-muted-foreground text-left hover:text-foreground transition-colors"
                data-testid="link-terms"
              >
                Terms of Service
              </button>
            </div>
          </div>
        </div>

        <div className="border-t pt-6 text-center">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} GBP Pro Agency. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
