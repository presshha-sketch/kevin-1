import { motion } from "framer-motion";

const stats = [
  { value: "100+", label: "Profiles Optimized" },
  { value: "3x", label: "Avg. Visibility Increase" },
  { value: "4.9", label: "Client Satisfaction" },
  { value: "0", label: "Long-Term Contracts" },
];

export function CredibilityStrip() {
  return (
    <section className="py-10 border-b bg-muted/30" data-testid="section-credibility">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-8"
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="text-center"
              data-testid={`credibility-${stat.label.substring(0, 15).replace(/\s/g, "-").toLowerCase()}`}
            >
              <div className="text-2xl sm:text-3xl font-bold text-primary mb-1">{stat.value}</div>
              <div className="text-sm text-muted-foreground font-medium">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
