import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Mail } from "lucide-react";
import { SiFacebook } from "react-icons/si";
import logoPath from "@assets/C9343283-07B3-4632-BBFA-DD22E79ADCFF_1770732893773.png";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    setMobileOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  const navLinks = [
    { label: "Services", id: "services" },
    { label: "How It Works", id: "how-it-works" },
    { label: "Why It Works", id: "why-it-works" },
    { label: "Pricing", id: "pricing" },
    { label: "FAQ", id: "faq" },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 bg-white/95 dark:bg-background/95 backdrop-blur-md ${
        scrolled ? "shadow-sm" : ""
      }`}
      data-testid="navbar"
    >
      <div className="bg-[#1a237e] text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4 h-9 text-sm">
            <div className="flex items-center gap-4 flex-wrap">
              <a
                href="mailto:sales@gbpproagency.com"
                className="flex items-center gap-1.5 text-white/90 hover:text-white transition-colors"
                data-testid="link-topbar-email"
              >
                <Mail className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">sales@gbpproagency.com</span>
                <span className="sm:hidden">Email Us</span>
              </a>
            </div>
            <div className="hidden md:flex items-center gap-3">
              <span className="text-white/70 text-xs">Serving businesses nationwide</span>
              <a
                href="https://www.facebook.com/share/16qifq9aqJ/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/70 hover:text-white transition-colors"
                data-testid="link-topbar-facebook"
              >
                <SiFacebook className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-16">
          <button
            onClick={() => scrollTo("hero")}
            className="flex items-center gap-2"
            data-testid="link-logo"
          >
            <img
              src={logoPath}
              alt="GBP Pro Agency"
              className="h-8 w-auto"
              data-testid="img-logo"
            />
          </button>

          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollTo(link.id)}
                className="text-sm font-medium px-3 py-2 rounded-md transition-colors text-muted-foreground hover:text-foreground hover:bg-muted/50"
                data-testid={`link-${link.id}`}
              >
                {link.label}
              </button>
            ))}
            <div className="ml-2">
              <Button
                onClick={() => scrollTo("contact")}
                data-testid="button-get-started-nav"
              >
                Get a Free Audit
              </Button>
            </div>
          </div>

          <Button
            size="icon"
            variant="ghost"
            className="md:hidden"
            onClick={() => setMobileOpen(!mobileOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileOpen ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden bg-white dark:bg-background border-b shadow-lg">
          <div className="px-4 py-3 flex flex-col gap-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollTo(link.id)}
                className="text-sm font-medium text-muted-foreground text-left py-2.5 px-3 rounded-md hover:bg-muted/50"
                data-testid={`link-mobile-${link.id}`}
              >
                {link.label}
              </button>
            ))}
            <div className="border-t my-2 pt-2 flex flex-col gap-2">
              <a
                href="mailto:sales@gbpproagency.com"
                className="flex items-center gap-2 text-sm text-muted-foreground px-3 py-1.5"
                data-testid="link-mobile-email"
              >
                <Mail className="w-4 h-4" />
                sales@gbpproagency.com
              </a>
            </div>
            <div className="pt-2 pb-1">
              <Button
                onClick={() => scrollTo("contact")}
                className="w-full"
                data-testid="button-get-started-mobile"
              >
                Get a Free Audit
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
