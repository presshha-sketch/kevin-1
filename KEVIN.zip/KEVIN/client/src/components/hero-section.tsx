import { Button } from "@/components/ui/button";
import { ArrowRight, MapPin } from "lucide-react";
import { motion } from "framer-motion";

export function HeroSection() {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="hero"
      className="relative min-h-[92vh] flex items-center overflow-hidden"
      data-testid="section-hero"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-[#1a237e] via-[#1565c0] to-[#0d47a1]" />
      <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "40px 40px" }} />
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-28 w-full">
        <div className="max-w-2xl">
          <motion.div
            className="inline-flex items-center gap-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/15 px-4 py-1.5 mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-sm text-white/90 font-medium">Google Business Profile Experts</span>
          </motion.div>

          <motion.h1
            className="text-4xl sm:text-5xl lg:text-[3.5rem] font-bold text-white leading-[1.15] tracking-tight mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            Get More Local Calls from{" "}
            <span className="inline-flex items-center gap-2 text-transparent bg-clip-text bg-gradient-to-r from-blue-200 to-white">
              <MapPin className="w-10 h-10 text-red-400 inline-block" style={{ filter: "drop-shadow(0 0 8px rgba(255,100,100,0.4))" }} />
              Google Maps
            </span>
          </motion.h1>

          <motion.p
            className="text-lg text-blue-100/80 mb-10 max-w-xl leading-relaxed"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            We optimize and manage your Google Business Profile so you rank
            better in local search and convert more customers — without wasting
            money on ads that don't stick.
          </motion.p>

          <motion.div
            className="flex flex-col sm:flex-row gap-3"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Button
              size="lg"
              onClick={() => scrollTo("contact")}
              className="text-base bg-white text-[#1565c0] border-white no-default-hover-elevate hover:bg-blue-50 transition-colors"
              data-testid="button-hero-audit"
            >
              Get a Free GBP Audit
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => scrollTo("contact")}
              className="text-base backdrop-blur-sm bg-white/5 border-white/25 text-white no-default-hover-elevate hover:bg-white/10 transition-colors"
              data-testid="button-hero-call"
            >
              Book a Call
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
