import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Target, Star, MousePointerClick } from "lucide-react";

const factors = [
  {
    icon: Target,
    title: "Profile Relevance",
    description:
      "Categories, services, and content that tell Google exactly what you do and where — so you match the right searches.",
    items: ["Category alignment", "Service descriptions", "Keyword-rich content"],
    accent: "border-t-[#4285F4]",
    iconColor: "text-[#4285F4]",
    iconBg: "bg-[#4285F4]/8",
  },
  {
    icon: Star,
    title: "Prominence",
    description:
      "Reviews, engagement, and consistent activity that prove to Google your business is active, trusted, and popular.",
    items: ["Review growth", "Regular posting", "Citation consistency"],
    accent: "border-t-[#FBBC05]",
    iconColor: "text-[#FBBC05]",
    iconBg: "bg-[#FBBC05]/10",
  },
  {
    icon: MousePointerClick,
    title: "Conversion",
    description:
      "Optimized profiles that turn searchers into callers, visitors, and paying customers.",
    items: ["Calls & clicks", "Direction requests", "Website visits"],
    accent: "border-t-[#34A853]",
    iconColor: "text-[#34A853]",
    iconBg: "bg-[#34A853]/8",
  },
];

export function WhyItWorksSection() {
  return (
    <section
      id="why-it-works"
      className="py-20 sm:py-28 bg-muted/30"
      data-testid="section-why-it-works"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <motion.p
            className="text-sm font-semibold tracking-widest uppercase text-primary mb-3"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Why It Works
          </motion.p>
          <motion.h2
            className="text-3xl sm:text-4xl font-bold tracking-tight mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            Google Maps Rankings, Simplified
          </motion.h2>
          <motion.p
            className="text-muted-foreground text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            Google Maps results are driven by <strong>relevance</strong>,{" "}
            <strong>distance</strong>, and <strong>prominence</strong>. You
            can't control distance — but you can improve everything else.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {factors.map((factor, index) => (
            <motion.div
              key={factor.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card
                className={`p-6 h-full border-t-[3px] ${factor.accent}`}
                data-testid={`card-factor-${index}`}
              >
                <div className={`w-10 h-10 rounded-md ${factor.iconBg} flex items-center justify-center mb-4`}>
                  <factor.icon className={`w-5 h-5 ${factor.iconColor}`} />
                </div>
                <h3 className="text-base font-semibold mb-2">{factor.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                  {factor.description}
                </p>
                <ul className="space-y-2">
                  {factor.items.map((item) => (
                    <li
                      key={item}
                      className="flex items-center gap-2 text-sm text-muted-foreground"
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
