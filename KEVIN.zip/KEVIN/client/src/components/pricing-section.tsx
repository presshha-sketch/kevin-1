import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const features = [
  "Google Business Profile Setup & Optimization",
  "4 SEO-optimized posts per week",
  "Monthly GBP Management",
  "Review Growth & Response Management",
  "Local Listings Consistency",
  "Simple Monthly Reporting",
  "No long-term contracts",
  "Cancel anytime",
];

export function PricingSection() {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="pricing"
      className="py-20 sm:py-28"
      data-testid="section-pricing"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <motion.p
            className="text-sm font-semibold tracking-widest uppercase text-primary mb-3"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Simple Pricing
          </motion.p>
          <motion.h2
            className="text-3xl sm:text-4xl font-bold tracking-tight mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            One Plan. Everything Included.
          </motion.h2>
          <motion.p
            className="text-muted-foreground text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            Flat weekly pricing. No surprises. No setup fees. No long-term
            contracts.
          </motion.p>
        </div>

        <motion.div
          className="max-w-md mx-auto"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
        >
          <Card
            className="p-7 sm:p-9 relative border-primary/20"
            data-testid="card-pricing"
          >
            <div className="absolute -top-3 left-1/2 -translate-x-1/2">
              <Badge className="text-xs no-default-hover-elevate no-default-active-elevate">
                Full GBP Management
              </Badge>
            </div>

            <div className="text-center mb-7 pt-2">
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-5xl font-bold">$100</span>
                <span className="text-muted-foreground text-lg">/week</span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Cancel anytime. No setup fees.
              </p>
            </div>

            <div className="space-y-3 mb-7">
              {features.map((feature) => (
                <div
                  key={feature}
                  className="flex items-center gap-3"
                  data-testid={`feature-${feature.substring(0, 20).replace(/\s/g, "-").toLowerCase()}`}
                >
                  <CheckCircle2 className="w-4.5 h-4.5 text-[#34A853] flex-shrink-0" />
                  <span className="text-sm">{feature}</span>
                </div>
              ))}
            </div>

            <Button
              className="w-full text-base"
              size="lg"
              onClick={() => scrollTo("contact")}
              data-testid="button-pricing-cta"
            >
              Get a Free GBP Audit
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
