import { Card } from "@/components/ui/card";
import { MapPin, PhoneOff, Star, Users } from "lucide-react";
import { motion } from "framer-motion";

const problems = [
  {
    icon: MapPin,
    title: "You're Not in the Maps 3-Pack",
    description:
      "The top 3 Google Maps results get the vast majority of clicks and calls. If you're not there, you're invisible to ready-to-buy customers.",
    color: "text-[#4285F4]",
    bg: "bg-[#4285F4]/8",
  },
  {
    icon: PhoneOff,
    title: "Showing Up, But Not Getting Calls",
    description:
      "Your profile might be live, but if it's incomplete or stale, customers scroll right past you to a competitor who looks more trustworthy.",
    color: "text-[#EA4335]",
    bg: "bg-[#EA4335]/8",
  },
  {
    icon: Star,
    title: "Reviews Are Weak or Unmanaged",
    description:
      "Few reviews, no responses, or outdated feedback signals to Google (and customers) that your business isn't active or reliable.",
    color: "text-[#FBBC05]",
    bg: "bg-[#FBBC05]/10",
  },
  {
    icon: Users,
    title: "Competitors Outrank You",
    description:
      "They're not better at what they do — they're just better at showing Google they exist. We fix that.",
    color: "text-[#34A853]",
    bg: "bg-[#34A853]/8",
  },
];

export function ProblemSection() {
  return (
    <section
      id="problem"
      className="py-20 sm:py-28"
      data-testid="section-problem"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <motion.p
            className="text-sm font-semibold tracking-widest uppercase text-primary mb-3"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Sound Familiar?
          </motion.p>
          <motion.h2
            className="text-3xl sm:text-4xl font-bold tracking-tight mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            The Problem Most Local Businesses Face
          </motion.h2>
          <motion.p
            className="text-muted-foreground text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            You know you need to be found on Google — but you're not sure why
            it's not working, or what to fix first.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {problems.map((problem, index) => (
            <motion.div
              key={problem.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.08 }}
            >
              <Card
                className="p-6 h-full"
                data-testid={`card-problem-${index}`}
              >
                <div className="flex gap-4">
                  <div className={`flex-shrink-0 w-11 h-11 rounded-md ${problem.bg} flex items-center justify-center`}>
                    <problem.icon className={`w-5 h-5 ${problem.color}`} />
                  </div>
                  <div>
                    <h3 className="text-base font-semibold mb-1.5">{problem.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {problem.description}
                    </p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
