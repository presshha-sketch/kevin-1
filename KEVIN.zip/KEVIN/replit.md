# GBP Pro Agency - Landing Page

## Overview
Marketing landing page for GBP Pro Agency, a Google Business Profile optimization service for local businesses. The site promotes their $100/week managed GBP service with a lead capture form. Domain: gbpproagency.com

## Recent Changes
- 2026-02-10: Complete design overhaul to Google-inspired professional aesthetic. Shifted color palette from teal to blue (primary: 217 91% 50%). Hero uses deep blue gradient. Problem/Why It Works sections use Google-colored accents (blue, red, yellow, green). Services upgraded to card grid. Credibility strip now shows numerical stats. Contact section adds trust signals. Removed 3 unused old components.
- 2026-02-10: Rebuilt landing page to match full requirements document. Added Problem, How It Works, Services, Why It Works, Credibility Strip, FAQ sections. Updated Hero copy/CTAs, contact form fields (website, city, google listing URL), footer with contact info/legal links. Replaced icon logo with uploaded brand logo.

## Architecture
- **Frontend**: React + Vite single-page landing with sections: Hero, Credibility Strip, Problem, How It Works, Services, Why It Works, Pricing, Contact, FAQ
- **Backend**: Express API with single POST endpoint `/api/leads` for lead capture
- **Database**: PostgreSQL with `leads` table for form submissions
- **Styling**: Tailwind CSS with Google-inspired blue theme (primary: 217 91% 50%), Inter font, Google-colored accents (blue #4285F4, red #EA4335, yellow #FBBC05, green #34A853)

## Key Files
- `client/src/pages/landing.tsx` - Main landing page composing all sections
- `client/src/components/hero-section.tsx` - Hero with headline + dual CTAs
- `client/src/components/credibility-strip.tsx` - Trust indicators strip
- `client/src/components/problem-section.tsx` - 4 pain point cards
- `client/src/components/how-it-works-section.tsx` - 3-step process
- `client/src/components/services-section.tsx` - Services bullet list
- `client/src/components/why-it-works-section.tsx` - Relevance/distance/prominence factors
- `client/src/components/pricing-section.tsx` - $100/week pricing card
- `client/src/components/contact-section.tsx` - Lead capture form
- `client/src/components/faq-section.tsx` - 7 FAQ items with accordion
- `client/src/components/navbar.tsx` - Fixed nav with logo
- `client/src/components/footer.tsx` - Contact info, links, legal
- `shared/schema.ts` - Lead schema with Zod validation
- `server/routes.ts` - Lead submission API route
- `server/storage.ts` - Database storage using Drizzle ORM

## API
- `POST /api/leads` - Submit lead form (name, email, phone, businessName, businessType, website?, city?, googleListingUrl?, message?)

## User Preferences
- Logo: attached_assets/C9343283-07B3-4632-BBFA-DD22E79ADCFF_1770732893773.png
- Domain: gbpproagency.com
